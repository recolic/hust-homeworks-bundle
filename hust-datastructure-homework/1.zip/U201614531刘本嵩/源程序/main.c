#include "experiment1.h"

char *gp_sqlists_filename = "./sqlists.dat";
char *gp_sqlistdate_filename = "./sqlistdate.dat";
char *gp_sqlistelem_filename = "./sqlistelem.dat";
int main() {
  SqLists *pLists = &Lists;
  SqList *pList = NULL;
  size_t opListNum = 0;
  size_t op = 1;
  size_t i;
  size_t elemNum;
  ElemType elem, elem2;
  char choise;
  LoadDate();
  while (op) {
#ifdef WIN32
    system("cls");
#else
    system("clear");
#endif
    printf("\n\t\t\t线性表的顺序实现\n");

    printf("**当前线性表表数：%d\n", pLists->length);
    printf("**最大线性表数：%d\n", MAX_SQLIST_NUM);
    printf("**当前操作线性表(编号从1开始)：");
    if (opListNum <= 0) {
      printf("无，2-12操作前请先选择要操作的线性表或创建表\n");
    } else {
      printf("线性表%d\n", opListNum);
    }
    printf("      Menu for Linear Table On Sequence Structure \n");
    printf("-------------------------------------------------\n");
    printf("    	  1. InitList        8. PriorElem\n");
    printf("    	  2. DestroyList     9. NextElem\n");
    printf("    	  3. ClearList       10. ListInsert \n");
    printf("    	  4. ListEmpty       11. ListDelete\n");
    printf("    	  5. ListLength      12. ListTraverse\n");
    printf("    	  6. GetElem         13. ChooseList\n");
    printf("    	  7. LocateElem      14. SaveDate\n");
    printf("    	  0. Exit\n");
    printf("-------------------------------------------------\n");
    printf("    请选择你的操作[0~14]:");
    scanf("%d", &op);
    getchar();
    switch (op) {
    case 1:
      if (pLists->length >= MAX_SQLIST_NUM) {
        printf("线性表数达到最大，不允许创建新表!\n");
        getchar();
        break;
      }
      if (!(pLists->pSqList[pLists->length++] =
                (SqList *)malloc(sizeof(SqList))))
        exit(OVERFLOW); //??? Shit copied from text book
      if (InitList(pLists->pSqList[pLists->length - 1]) == OK)
        printf("线性表创建成功！\n\n回车以继续进行下一步操作\n");
      else {
        printf("线性表创建失败！\n\n回车以继续进行下一步操作\n");
        free(pLists->pSqList[pLists->length - 1]);
      }
      getchar();
      break;
    case 2:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      if (DestroyList(pList))
        printf("线性表销毁成功！\n\n回车以继续进行下一步操作\n");
      if (opListNum < pLists->length) {
        for (i = opListNum; i < pLists->length - 1; i++)
          pLists->pSqList[i - 1] = pLists->pSqList[i];
      }
      pLists->length--;
      opListNum = 0;
      getchar();
      break;
    case 3:
      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      if (ClearList(pList))
        printf("线性表置空成功！\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 4:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      if (ListEmpty(*pList))
        printf("线性表为空\n\n回车以继续进行下一步操作\n");
      else
        printf("线性表非空\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 5:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("线性表表长：%d\n\n回车以继续进行下一步操作\n",
             ListLength(*pList));
      getchar();
      break;
    case 6:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }

      printf("请输入要查找的元素序号:");
      scanf("%d", &elemNum);
      getchar();
      if (elemNum >= 1 && elemNum <= pList->length) {
        GetElem(*pList, elemNum, &elem);
        printf("元素值：%d\n\n回车以继续进行下一步操作\n", elem);
      } else
        printf("元素不存在\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 7:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("请输入要查找的元素值：");
      scanf("%d", &elem);
      getchar();
      if ((elemNum = LocateElem(*pList, elem)))
        printf("位序:%d\n\n回车以继续进行下一步操作\n", elemNum);
      else
        printf("元素不存在\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 8:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("请输入要查找的元素值：");
      scanf("%d", &elem);
      getchar();
      if (PriorElem(*pList, elem, &elem2))
        printf("前驱结点元素值:%d\n\n回车以继续进行下一步操作\n", elem2);
      else
        printf("前驱不存在!\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 9:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("请输入要查找的元素值：");
      scanf("%d", &elem);
      getchar();
      if (NextElem(*pList, elem, &elem2))
        printf("后继结点元素值:%d\n\n回车以继续进行下一步操作\n", elem2);
      else
        printf("后继不存在!\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 10:

      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("请输入要插入的元素值：");
      scanf("%d", &elem);
      getchar();
      printf("请输入要插入位序：");
      scanf("%d", &elemNum);
      getchar();
      if (ListInsert(pList, elemNum, elem))
        printf("插入成功！\n\n回车以继续进行下一步操作\n");
      else
        printf("插入失败！\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 11:
      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      printf("请输入要删除的位序：");
      scanf("%d", &elemNum);
      getchar();
      if (ListDelete(pList, elemNum, &elem)) {
        printf("\n删除的元素值：%d\n", elem);
        printf("删除成功！\n\n回车以继续进行下一步操作\n");
      } else
        printf("删除失败！\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 12:
      if (opListNum < 1) {
        printf("请先选择需要操作的线性表！\n");
        getchar();
        break;
      }
      if (!ListTraverse(*pList))
        printf("线性表是空表！\n\n回车以继续进行下一步操作\n");
      getchar();
      break;
    case 13:
      pList = ChooseList(&opListNum);
      printf("当前线性表：表%d\n\n回车以继续进行下一步操作\n", opListNum);
      getchar();
      break;
    case 14:
      if (SaveDate()) {
        printf("数据保存成功！\n\n回车以继续进行下一步操作\n");
      } else {
        printf("数据保存失败！\n\n回车以继续进行下一步操作\n");
      }
      getchar();
    }
  }

  printf("保存数据?(Y/N)\n");
  scanf("%1s", &choise);
  getchar();
  if (choise == 'Y' || choise == 'y') {
    if (SaveDate())
      printf("数据保存成功！\n");
    else
      printf("数据保存失败！\n");
  }
  printf("欢迎下次再使用本系统！\n");
  getchar();
  return 0;
}
